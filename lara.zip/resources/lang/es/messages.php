<?php

return [
    'welcome' => 'Bienvenue sur notre site web!',
];