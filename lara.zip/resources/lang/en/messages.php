<?php

return [
    'welcome' => 'Welcome to our website!',
];