<?php

return [
    'welcome' => '¡Bienvenido a nuestro sitio web!',
];