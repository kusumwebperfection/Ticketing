<?php

return [
    'welcome' => 'bem-vindo',
    'Roles' => '- Papeis e Permissões',

];