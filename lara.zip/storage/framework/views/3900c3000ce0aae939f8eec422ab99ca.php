<div class="dropdown">
  <?php
  $selected = session('locale') ? session('locale') : 'us';
  ?>
  <a href="#" class="btn bg-gradient-dark dropdown-toggle mb-0" data-bs-toggle="dropdown" id="navbarDropdownMenuLink2">
    <img src="<?php echo e(asset('assets//img/icons/flags/' . strtoupper($selected).'.png')); ?>" /> <?php echo e($selected); ?>

  </a>
  <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2">
    <?php $__currentLoopData = config('app.supported_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
      <a class="dropdown-item" href="#" onclick="event.preventDefault(); document.getElementById('locale-form-<?php echo e($locale); ?>').submit();">
        <img src="<?php echo e(asset('assets/img/icons/flags/' . strtoupper($locale).'.png')); ?>" />
        <?php echo e($label); ?>

      </a>
      <form id="locale-form-<?php echo e($locale); ?>" method="post" action="<?php echo e(route('locale.switch')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="locale" value="<?php echo e($locale); ?>">
      </form>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div><?php /**PATH F:\LocalWorkspace\lara\resources\views/components/LanguageSwitcher.blade.php ENDPATH**/ ?>