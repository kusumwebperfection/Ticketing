<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div><?php echo e($error); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<form action="<?php echo e(route('roles.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="name">Role Name:</label>
    <input type="text" name="name" id="name">
    <button type="submit">Create Role</button>
</form>
<?php /**PATH F:\LocalWorkspace\ReactAuth\backend\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>