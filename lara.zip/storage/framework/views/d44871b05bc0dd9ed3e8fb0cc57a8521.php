 <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/chartjs.min.js')); ?>"></script> 
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <script src="<?php echo e(asset('assets/js/argon-dashboard.min.js?v=2.0.4')); ?>"></script><?php /**PATH F:\LocalWorkspace\lara\resources\views/layouts/mainScripts.blade.php ENDPATH**/ ?>