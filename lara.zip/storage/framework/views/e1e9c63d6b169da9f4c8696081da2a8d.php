
<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-md-10 mt-4">
            <div class="card">
                <div class="table-responsive">
                    <table class="table align-items-center mb-0">
                        <?php if(count($users) > 0): ?>
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">User Name</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Function</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Change Role</th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Created At</th>
                                <th class="text-secondary opacity-7">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="d-flex px-2 py-1">
                                        <div>
                                            <?php if(is_null($user->profile_pic)): ?>
                                            <img src="<?php echo e(asset('/public/img/SuperAdminPic.png')); ?>" class="avatar avatar-sm me-3">
                                            <?php else: ?>
                                            <img src="<?php echo e(asset('storage/' .$user->profile_pic)); ?>" class="avatar avatar-sm me-3">
                                            <?php endif; ?>
                                        </div>
                                        <div class="d-flex flex-column justify-content-center">
                                            <h6 class="mb-0 text-xs"><?php echo e($user->name); ?></h6>
                                            <p class="text-xs text-secondary mb-0"><?php echo e($user->email); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $user['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="text-xs font-weight-bold mb-0"><?php echo e($roles->name); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <p class="text-xs text-secondary mb-0">Organization</p>
                                </td>
                                <td class="align-middle text-center text-sm">
                                    <span class="badge badge-sm bg-gradient-success">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Manage Roles')): ?>
                                        <select class="roleSelect" name="role" userid='<?php echo e($user->id); ?>'>
                                            <?php $__currentLoopData = roleDropdown(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleId => $roleName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($user->currentRole()->id): ?>
                                            <option value="<?php echo e($roleId); ?>" <?php echo e($user->currentRole()->id == $roleId ? 'selected' : ''); ?>><?php echo e($roleName); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td class="align-middle text-center">
                                    <span class="text-secondary text-xs font-weight-bold"><?php echo e($user->created_at->format('d/m/y')); ?></span>
                                </td>
                                <td class="align-middle">
                                    <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                                        Edit
                                    </a>
                                    <a class="delete-role-btn btn btn-link text-danger text-gradient px-3 mb-0 deleteUser" userid='<?php echo e($user->id); ?>' href="javascript:;">
                                        <i class="far fa-trash-alt me-2" aria-hidden="true"></i>Delete
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $('.roleSelect').change(function() {
        var roleId = $(this).val();
        var userId = $(this).attr('userid');
        var data = {
            _token: '<?php echo e(csrf_token()); ?>',
            _method: 'PUT',
            role_id: roleId,
            action: 'updateRole',
        };
        $.ajax({
            type: 'POST',
            url: '/users/' + userId,
            data: data,
            success: function(response) {
                location.reload();
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                // Handle error response
            }
        });
    });

    $('.deleteUser').click(function() {
        var userId = $(this).attr('userid');
        var data = {
            _token: '<?php echo e(csrf_token()); ?>',
            _method: 'DELETE',
        };
        $.ajax({
            type: 'POST',
            url: '/users/' + userId,
            data: data,
            success: function(response) {
                location.reload();
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                // Handle error response
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/adminMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LocalWorkspace\lara\resources\views/admin/users/index.blade.php ENDPATH**/ ?>