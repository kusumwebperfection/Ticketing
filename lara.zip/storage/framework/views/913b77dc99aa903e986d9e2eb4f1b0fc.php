<!-- edit.blade.php -->

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div><?php echo e($error); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<form action="<?php echo e(route('roles.update', $role)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="name">Role Name:</label>
    <input type="text" name="name" id="name" value="<?php echo e($role->name); ?>">
    <button type="submit">Update Role</button>
</form>
<?php /**PATH F:\LocalWorkspace\ReactAuth\backend\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>